const express = require('express');
const app = express();
const port = 3000;
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://akshayshelke:gallagher2020@akshay-cluster.u9f5oc1.mongodb.net/?retryWrites=true&w=majority";


app.get('/', (req, res) => {
    res.send('Hello World,this is responce from slash/ entry and  express app');
});

app.get('/getusers', (req, res) => {
    try {
      MongoClient.connect(url, function(err, db) {
          if (err) throw err;
          var dbo = db.db("dbshelke");
          dbo.collection("dbakshay").find().toArray(function(err, result) {
            if (err) throw err;
            res.send(result)
            db.close();
          });
        });
  } catch (error) {
      console.log(error)
  }
});


app.listen(port, () => console.log(`nodejs Server is starting on port 3000`))
